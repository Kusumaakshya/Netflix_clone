let accordian = document.getElementsByClassName("FAQ__title");
function redirectToSignIn() {
  window.location.href = "step1.html"; // This redirects to the signin page
}
for (let i = 0; i < accordian.length; i++) {
  accordian[i].addEventListener("click", function () {
    if (this.childNodes[1].classList.contains("fa-plus")) {
      this.childNodes[1].classList.remove("fa-plus");
      this.childNodes[1].classList.add("fa-times");
    } else {
      this.childNodes[1].classList.remove("fa-times");
      this.childNodes[1].classList.add("fa-plus");
    }

    let content = this.nextElementSibling;
    if (content.style.maxHeight) {
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    }
  });
  function submitSignupForm() {
    const email = document.getElementById('emailInput').value;
    if (email) {
      // Store email in localStorage temporarily
      localStorage.setItem('signupEmail', email);
      redirectToSignIn();
    } else {
      alert('Please enter a valid email address');
    }
  }
  
  function redirectToSignIn() {
    window.location.href = "step1.html";
  }

}